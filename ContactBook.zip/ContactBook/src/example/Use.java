package example;

public class Use {

	public static void main(String[] args) {
		
		Contact_book book = new Contact_book();
		book.manage();
	}

}
