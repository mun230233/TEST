/**
 * 
 */
/**
 * @author a50609
 *
 */
module ContactBook {
}